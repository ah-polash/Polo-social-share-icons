===Polo Social Share  ===
Tags: social share, social share icons, social share button, social media share, whatsapp share, viber share, line share, linkedin share, facebook share, twitter share, reditt share, teligram share 
Donate link: https://www.paypal.me/PolashPiu/20usd
Requires at least: 3.0.1
Tested up to: 5.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A lite weight Social media share plugin

== Description ==

WP Podcast is an user friendly podcasting plugin for WordPress which has lots of options and and functionality to run your podcasting website. 

Wanna see how it works? [Click Here To see demo ](http://abuhayatpolash.com/ "See demo")  


= Features =
* Podcast mp3, wav, and ogg audio file
* HTML5 compatible so it will play audio files in most of the mobile devices.
* Works on all major browsers - IE7, IE8, IE9, Safari, Firefox, Chrome
* The player is responsive.
* Integrated social share icon .
* Shortcode driven. so that you can publish any podcast anywhere in your wordpress.
* Audio file download button and control over it.
* User can change the audio speed using setting icon in the front end. 
* 2 Theme included.
* You can add podcast in widget area too.
* Fully customizable and compact.
* You can create unlimited podcast
* User friendly interface
* Powered by html5 


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-directory` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use shortcode in page, post or in widgets.
4. If you want to use shortcode in your theme template file, Place `<?php echo do_shortcode('YOUR_SHORTCODE'); ?>` in the templates


== Frequently Asked Questions ==

= How do I install this plugin? =

You can install as others regular wordpress plugin. No different way. Please see on installation tab.

= I am not a web developer, Can i configure the podcast ? =

Absolutely, It is very easy to use and there are no other complex configuration wizard. 

= What type of audio can i play? =

You can play .Mp3, .Wav and .Ogg file

= How many Podcast can i create and publish ? =

The sky is the limit. (Unlimited)



== Screenshots ==

1. Sidebar menu
2. Create New Podcast
3. Front end
3. Shortcode

== Changelog ==

= 1.0 =
* Initial Release